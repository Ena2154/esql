# esql/versions/esql_v1_1_0/__init__.py

from .main import MainCls as Connection
from .boot import run