# esql/version.py

# 利用可能なバージョンをリストで管理
AVAILABLE_VERSIONS = ['1.0.0', '1.1.0']

# デフォルトで使われる最新バージョンを指定
LATEST_VERSION = '1.1.0'