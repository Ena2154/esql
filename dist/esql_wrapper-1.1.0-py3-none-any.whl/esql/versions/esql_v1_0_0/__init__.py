# esql/versions/esql_v1_0_0/__init__.py

from .main import MainCls as Connection
from .boot import run