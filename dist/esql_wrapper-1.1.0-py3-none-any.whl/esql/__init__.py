# esql/__init__.py

from . import version as ver

# --- 各バージョンのモジュールをインポート ---
from .versions.esql_v1_1_0 import boot as boot_v1_1, main as main_v1_1
from .versions.esql_v1_0_0 import boot as boot_v1_0, main as main_v1_0

# --- ファクトリ関数（バージョンに応じて実体を切り替える） ---

def run(db_name, callback, message=False, use_generator=False, query_name: str = "", version=None):
    """
    高レベルAPI `run`。バージョンと処理名を指定して実行できます。
    """
    if version is None:
        version = ver.LATEST_VERSION

    if version == '1.1.0':
        return boot_v1_1.run(db_name, callback, message, use_generator, query_name)
    elif version == '1.0.0':
        if query_name:
            print(f"警告: 'query_name' 引数はバージョン {version} ではサポートされていません。")
        return boot_v1_0.run(db_name, callback, message)
    else:
        raise ValueError(f"指定されたバージョン '{version}' は利用できません。")

def Connection(connect="sample", message=False, use_generator=False, version=None):
    """
    低レベルAPI `Connection`。バージョンを指定してインスタンスを生成できます。
    """
    if version is None:
        version = ver.LATEST_VERSION
    
    if version == '1.1.0':
        return main_v1_1.MainCls(connect, message, use_generator)
    elif version == '1.0.0':
        return main_v1_0.MainCls(connect, message)
    else:
        raise ValueError(f"指定されたバージョン '{version}' は利用できません。")